#include <stdio.h>



int main(){

    
    char a ;
    printf(" Masukan Karakter = ");
    scanf("%c",&a);
    printf(" Hasil Karakter Dalam Angka/Integer = %i\n",a);

    return 0;
}