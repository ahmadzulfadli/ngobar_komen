#include <stdio.h>

int main(){

    int a = 10 ;
    printf("Nilai a = %i \n", a);
    a++; // kalian bisa pake a++(post increment) atau ++a(pre increment)
    printf("Nilai a yang baru = %i\n", a);
    return 0;
}