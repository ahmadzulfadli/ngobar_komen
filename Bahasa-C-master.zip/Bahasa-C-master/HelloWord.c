#include <stdio.h>

int main(){
    
    printf("Selamat Datang Di Markenji\n"); // ini akan di cetak 
    /*printf("Selamat Datang Di Markenji");
    printf("Selamat Datang Di Markenji\n");*/
    return 0;
}