#include <stdio.h>

int main(){

    _Bool mangga = 1;
    printf("Markenji Mau Beli (1 untuk iya , 0 untuk tidak) = %i\n", mangga);
    return 0;
}