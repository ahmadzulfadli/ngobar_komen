#include <stdio.h>

int main(){

   int a = 6 ;
   int b = a/2;

    printf("Nilai b = %d\nNilai a = %i\n",b,a);
    return 0;
}