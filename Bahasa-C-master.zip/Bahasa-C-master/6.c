#include <stdio.h>

int main(){
     int a,b,c,d;
     
     a = 10;
     b = 200;
     c = 5;
     d = b*a-b/c+a;
     printf("Hasil dari d adalah = %i\n",d);
     return 0;

     

}