#include <stdio.h>

// PERULANGAN FOR ATAU LOOPING FOR
// 1 INISIALISATION ATAU STAR 
// 2 KONDISI
// 3 OPERASI ATAU INCREMENT

int main(){

    int a;
    scanf("%i", &a);
    for(int i = 0 ; i < a ; i++)
    {

        printf("%i\n",i);

    }

    return 0;
}