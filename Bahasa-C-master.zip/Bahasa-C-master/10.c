#include <stdio.h>

int main(){

    int a,b,c,d,e,f,g,h,i,j ;
    a = 10;
    b = 10;
    c = 10;
    d = 10;
    e = 10;
    f = 10;
    g = 10;
    h = 10;
    i = 10;
    j = 10;

    // Contoh Operator  || Keterangan
    a += 2;                // Kependekan dari a = a + 2;
    printf("Hasil a = %i\n",a);
     b -= 2;                // Kependekan dari a = a + 2;
    printf("Hasil b = %i\n",b);
     c *= 2;                // Kependekan dari a = a + 2;
    printf("Hasil c = %i\n",c);
     d /= 2;                // Kependekan dari a = a + 2;
    printf("Hasil d = %i\n",d);
     e %= 2;                // Kependekan dari a = a + 2;
    printf("Hasil e = %i\n",e);
     f <<= 2;                // Kependekan dari a = a + 2;
    printf("Hasil f = %i\n",f);
     g >>= 2;                // Kependekan dari a = a + 2;
    printf("Hasil g = %i\n",g);
     h &= 2;                // Kependekan dari a = a + 2;
    printf("Hasil h = %i\n",h);
     i |= 2;                // Kependekan dari a = a + 2;
    printf("Hasil i = %i\n",i);
     j ^= 2;                // Kependekan dari a = a + 2;
    printf("Hasil j = %i\n",j); 
     
     return 0;
}