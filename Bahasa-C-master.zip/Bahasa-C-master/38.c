#include <stdio.h>

int main ()
{
    
    int x = 0;
    do
    {

        printf("Hasil = %i \n",x);
        x++;

    }while( x <= 6 );



    return 0;

}



/*
intialisasi
do
{

statement 
operator

}while(Kondisi);

*/