#include <stdio.h>
#include <stdbool.h>

int main(){

    int a;
    bool b; // false dan true
    printf("Masukan Nilai a = ");
    scanf("%i",&a);
    b = a;

    if(b)
    {

       printf("Oke Hasilnya TRUE \n ");

    }

}