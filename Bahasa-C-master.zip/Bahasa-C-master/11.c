#include <stdio.h>

int main(){
    int a,b,c,d,e;
    a = 10;
    b = 10;
    c = 10;
    d = 10;
    e = 11;
    a+=2;
    printf("Hasil dari a = %i\n",a);
    b-=2;
    printf("Hasil dari a = %i\n",b);
    c*=2;
    printf("Hasil dari a = %i\n",c);
    d/=2;
    printf("Hasil dari a = %i\n",d);
    e%=2;
    printf("Hasil dari a = %i\n",e);
    return 0;
    
}