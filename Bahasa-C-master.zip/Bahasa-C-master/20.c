#include <stdio.h>

int main(){
 
  double a;
  printf("asdf : %.2f\n", 123.2323232323);
  /*printf("Masukan Nilai yang kamu mau = ");
  scanf("%lf",&a);
  printf(" %f \n %e\n %g\n",a,a,a);

  /* Perubahan Hasil untuk f , e , dan g 

  % f => dia menampilkan hasil decimal
  % e => dia menampilkankan notasi ilmiah / scientifix
  % g => dia menampilkan hasil dari komputer 
  */


  return 0;
}