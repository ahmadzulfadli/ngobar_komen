#include <stdio.h>

int main(){
    int a = 10;
    int b = 2 ;
    int hasil;
    hasil=a&b;
    printf("Hasilnya adalah = %i\n", hasil);
    return 0;
    
}