#include <stdio.h>

int main(){

    printf("Nilai dari 10 + 5 = %i \n", 10 + 5);
    printf("Nilai dari 10 - 5 = %i \n", 10 - 5);
    printf("Nilai dari 10 * 5 = %i \n", 10 * 5);
    printf("Nilai dari 10 / 5 = %i \n", 10 / 5);

    return 0;
}