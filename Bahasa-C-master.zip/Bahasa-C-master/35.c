#include <stdio.h>

// Judul while loop

int main(){

    int i = 0;
    while(i<=20)
    {
        i++;
        printf(" \tNilai = %i \n ",i);
        
    }

    return 0;
}