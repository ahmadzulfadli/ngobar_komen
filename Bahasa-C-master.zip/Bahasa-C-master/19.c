#include <stdio.h>

int main(){

  //2000 = 2 x 10^3
  //  2000 = 2e3 , e = 10^3
  int a = 2e3;
  printf("%i",a); 


  return 0;
}