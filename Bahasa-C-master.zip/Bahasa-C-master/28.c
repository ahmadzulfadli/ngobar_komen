#include <stdio.h>

int main(){

    int a;
    printf("Masukan Nilai a = ");
    scanf("%i",&a);

    if(a>10)
    {

       printf("Hore Selamat Kamu Berhasil");

    }
    else
    {
        printf("HMM Kamu Belum Berhasil");
    }

}

/*

if(kondisi)
{
    Blok Statement
}
else
{
    Blok Statement
}

*/