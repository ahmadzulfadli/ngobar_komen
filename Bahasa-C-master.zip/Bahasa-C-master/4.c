#include <stdio.h>

int main(){

    int a ; // declaration int , float , char , long , short , dll
    a = 12 ; // initialization



    int b = a / 2; // exprestion
    printf();
    return 0;
}