#include <stdio.h>

int main(){

    // %i untuk integer 
    // %f pertama untuk double 
    // %f kedua untuk float
    printf("interger = %i doubel = %f float = %f",1,1234.1234,1234.1234F);

    return 0;
}