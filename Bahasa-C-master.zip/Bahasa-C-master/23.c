#include <stdio.h>

// latihan ini tidak boleh lebih dari 127 
// Latihan Buat kalian coba ganti tanda + dengan - * dan / 
int main(){

    char a = 'B' + '1'; 
    printf("B(66) + 1(49) = %c(%i)\n", a, a);

    return 0;
}