#include <stdio.h>
#include <stdbool.h>

int main(){

    bool mangga = false ; // false or true

    printf("Markenji Mau Beli (1 untuk iya , 0 untuk tidak) = %i\n", mangga);
    return 0;
}